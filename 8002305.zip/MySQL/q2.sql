SELECT e.event_id, e.title, AVG(f.rating) AS avg_rating
FROM Events e
JOIN Feedback f ON e.event_id = f.event_id
GROUP BY e.event_id, e.title
HAVING COUNT(f.feedback_id) >= 10
   AND AVG(f.rating) = (
      SELECT MAX(avg_rating)
      FROM (
          SELECT AVG(rating) AS avg_rating
          FROM Feedback
          GROUP BY event_id
          HAVING COUNT(feedback_id) >= 10
      ) t
   );