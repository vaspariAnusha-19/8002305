const form = document.querySelector("#registrationForm");
const message = document.querySelector("#message");

form.addEventListener("submit", function(event) {

    event.preventDefault();

    console.log("Form submission started");

    const name = document.querySelector("#name").value;
    const email = document.querySelector("#email").value;

    console.log("Name:", name);
    console.log("Email:", email);

    const userData = {
        name: name,
        email: email
    };

    console.log("Payload Sent:", userData);

    debugger;

    fetch("https://jsonplaceholder.typicode.com/posts", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify(userData)

    })

    .then(response => {

        console.log("Response Received");

        return response.json();
    })

    .then(data => {

        console.log("Server Data:", data);

        message.textContent =
            "Registration Successful";
    })

    .catch(error => {

        console.log("Fetch Error:", error);

        message.textContent =
            "Registration Failed";
    });

});