const events = [
    {
        name: "Music Fest",
        category: "Music",
        seats: 5
    },
    {
        name: "Baking Workshop",
        category: "Workshop",
        seats: 3
    },
    {
        name: "Dance Night",
        category: "Music",
        seats: 4
    }
];

const container = document.querySelector("#eventContainer");
const filter = document.querySelector("#categoryFilter");
const searchBox = document.querySelector("#searchBox");

function displayEvents(eventList) {

    container.innerHTML = "";

    eventList.forEach(event => {

        const card = document.createElement("div");

        const title = document.createElement("h3");
        title.textContent = event.name;

        const category = document.createElement("p");
        category.textContent = `Category: ${event.category}`;

        const seats = document.createElement("p");
        seats.textContent = `Seats: ${event.seats}`;

        const button = document.createElement("button");
        button.textContent = "Register";

        button.onclick = function () {

            if (event.seats > 0) {
                event.seats--;
                seats.textContent = `Seats: ${event.seats}`;
            }
        };

        card.appendChild(title);
        card.appendChild(category);
        card.appendChild(seats);
        card.appendChild(button);

        container.appendChild(card);

    });
}

displayEvents(events);

filter.onchange = function () {

    const selectedCategory = filter.value;

    if (selectedCategory === "All") {
        displayEvents(events);
    } else {

        const filteredEvents = events.filter(
            event => event.category === selectedCategory
        );

        displayEvents(filteredEvents);
    }
};

searchBox.addEventListener("keydown", function () {

    const searchText = searchBox.value.toLowerCase();

    const searchedEvents = events.filter(event =>
        event.name.toLowerCase().includes(searchText)
    );

    displayEvents(searchedEvents);
});