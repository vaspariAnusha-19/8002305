const events = [
    {
        name: "Music Fest",
        category: "Music",
        seats: 50
    },
    {
        name: "Baking Workshop",
        category: "Workshop",
        seats: 30
    },
    {
        name: "Dance Night",
        category: "Music",
        seats: 20
    }
];

function addEvent(
    name = "New Event",
    category = "General",
    seats = 10
) {

    const newEvent = {
        name,
        category,
        seats
    };

    events.push(newEvent);
}

addEvent("Tech Talk", "Technology", 40);

events.forEach(event => {

    const { name, category, seats } = event;

    console.log(
        `Event: ${name} | Category: ${category} | Seats: ${seats}`
    );
});

const clonedEvents = [...events];

const musicEvents = clonedEvents.filter(
    event => event.category === "Music"
);

console.log("Music Events:");

musicEvents.forEach(event => {
    console.log(event.name);
});