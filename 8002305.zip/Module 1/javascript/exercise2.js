
const eventName = "Tech Conference";
const eventDate = "15 July 2026";
let availableSeats = 100;
console.log(`Event: ${eventName} | Date: ${eventDate} | Seats: ${availableSeats}`);
availableSeats--;
console.log(`Seats remaining after registration: ${availableSeats}`);