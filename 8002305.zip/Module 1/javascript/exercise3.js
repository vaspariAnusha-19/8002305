
const events = [
    {
        name: "Music Fest",
        date: "2026-06-15",
        seats: 20
    },
    {
        name: "Tech Workshop",
        date: "2025-01-10",
        seats: 0
    },
    {
        name: "Food Carnival",
        date: "2026-08-05",
        seats: 15
    }
];

const today = new Date();

events.forEach(event => {

    let eventDate = new Date(event.date);

    if (eventDate > today && event.seats > 0) {
        console.log(`Event: ${event.name} | Date: ${event.date} | Seats: ${event.seats}`);
    } else {
        console.log(`Event "${event.name}" is unavailable`);
    }
});



function registerUser(event) {

    try {

        if (event.seats <= 0) {
            throw new Error("No seats available");
        }

        event.seats--;

        console.log(`Successfully registered for ${event.name}`);
        console.log(`Remaining seats: ${event.seats}`);

    } catch (error) {

        console.log(`Registration Failed: ${error.message}`);
    }
}

// Try registration
registerUser(events[0]); // Success
registerUser(events[1]); // Error