let events = [];

events.push({
    name: "Baking",
    category: "Workshop"
});

events.push({
    name: "Music Night",
    category: "Music"
});

events.push({
    name: "Dance Show",
    category: "Music"
});

events.push({
    name: "Painting",
    category: "Workshop"
});

const musicEvents = events.filter(
    event => event.category === "Music"
);

console.log("Music Events:");

musicEvents.forEach(event => {
    console.log(event.name);
});

const displayCards = events.map(event =>
    `${event.category} on ${event.name}`
);

console.log("Formatted Display Cards:");

displayCards.forEach(card => {
    console.log(card);
});