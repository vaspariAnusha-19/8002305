const form = document.querySelector("#registrationForm");
const message = document.querySelector("#message");

form.addEventListener("submit", function(event) {

    event.preventDefault();

    const userData = {
        name: document.querySelector("#name").value,
        email: document.querySelector("#email").value
    };

    message.textContent = "Submitting registration...";

    setTimeout(() => {

        fetch("https://jsonplaceholder.typicode.com/posts", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify(userData)

        })

        .then(response => response.json())

        .then(data => {

            console.log(data);

            message.textContent =
                "Registration submitted successfully";
        })

        .catch(error => {

            console.log(error);

            message.textContent =
                "Registration failed";
        });

    }, 2000);

});