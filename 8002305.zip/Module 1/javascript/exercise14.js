$(document).ready(function () {

    $("#showBtn").click(function () {

        $("#eventCard").fadeIn();
    });

    $("#hideBtn").click(function () {

        $("#eventCard").fadeOut();
    });

    $("#registerBtn").click(function () {

        $("#message").text(
            "Registration Successful"
        );
    });

});