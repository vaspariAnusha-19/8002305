const events = [
    {
        name: "Music Fest",
        seats: 5
    },
    {
        name: "Tech Workshop",
        seats: 3
    }
];

const container = document.querySelector("#eventContainer");

events.forEach(event => {

    const card = document.createElement("div");

    const title = document.createElement("h3");
    title.textContent = event.name;

    const seats = document.createElement("p");
    seats.textContent = `Available Seats: ${event.seats}`;

    const registerBtn = document.createElement("button");
    registerBtn.textContent = "Register";

    const cancelBtn = document.createElement("button");
    cancelBtn.textContent = "Cancel";

    registerBtn.onclick = function () {

        if (event.seats > 0) {
            event.seats--;
            seats.textContent = `Available Seats: ${event.seats}`;
        }
    };

    cancelBtn.onclick = function () {

        event.seats++;
        seats.textContent = `Available Seats: ${event.seats}`;
    };

    card.appendChild(title);
    card.appendChild(seats);
    card.appendChild(registerBtn);
    card.appendChild(cancelBtn);

    container.appendChild(card);

});