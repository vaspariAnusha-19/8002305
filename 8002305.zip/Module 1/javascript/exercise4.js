let events = [];

function addEvent(name, category, seats) {
    events.push({
        name,
        category,
        seats
    });
}

function registerUser(eventName) {

    const event = events.find(e => e.name === eventName);

    if (event && event.seats > 0) {
        event.seats--;
        console.log(`Registered for ${event.name}`);
        console.log(`Remaining Seats: ${event.seats}`);
    } else {
        console.log("Registration failed");
    }
}

function filterEventsByCategory(category, callback) {

    const filteredEvents = events.filter(
        event => event.category === category
    );

    callback(filteredEvents);
}

function registrationTracker(category) {

    let totalRegistrations = 0;

    return function () {
        totalRegistrations++;
        console.log(`Total registrations for ${category}: ${totalRegistrations}`);
    };
}

addEvent("Music Fest", "Music", 50);
addEvent("Tech Workshop", "Technology", 30);
addEvent("Dance Show", "Music", 20);

registerUser("Music Fest");

const musicRegistration = registrationTracker("Music");

musicRegistration();
musicRegistration();

filterEventsByCategory("Music", function (filtered) {

    console.log("Music Events:");

    filtered.forEach(event => {
        console.log(event.name);
    });

});