const loading = document.querySelector("#loading");
const eventList = document.querySelector("#eventList");

fetch("https://jsonplaceholder.typicode.com/users")

.then(response => response.json())

.then(data => {

    console.log("Events fetched using .then()");

    data.slice(0, 5).forEach(event => {

        const li = document.createElement("li");
        li.textContent = event.name;

        eventList.appendChild(li);
    });

})

.catch(error => {
    console.log("Error:", error);
});

async function fetchEvents() {

    try {

        loading.style.display = "block";

        const response = await fetch(
            "https://jsonplaceholder.typicode.com/users"
        );

        const data = await response.json();

        eventList.innerHTML = "";

        data.slice(0, 5).forEach(event => {

            const li = document.createElement("li");
            li.textContent = event.name;

            eventList.appendChild(li);
        });

    }

    catch(error) {

        console.log("Fetch Error:", error);
    }

    finally {

        loading.style.display = "none";
    }
}

fetchEvents();