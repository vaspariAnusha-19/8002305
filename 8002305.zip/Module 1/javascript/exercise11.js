const form = document.querySelector("#registrationForm");

form.addEventListener("submit", function(event) {

    event.preventDefault();

    document.querySelector("#nameError").textContent = "";
    document.querySelector("#emailError").textContent = "";
    document.querySelector("#eventError").textContent = "";

    const name = form.elements["username"].value;
    const email = form.elements["email"].value;
    const selectedEvent = form.elements["event"].value;

    let valid = true;

    if (name === "") {
        document.querySelector("#nameError").textContent =
            " Name is required";
        valid = false;
    }

    if (email === "") {
        document.querySelector("#emailError").textContent =
            " Email is required";
        valid = false;
    }

    if (selectedEvent === "") {
        document.querySelector("#eventError").textContent =
            " Please select an event";
        valid = false;
    }

    if (valid) {

        console.log("Registration Successful");

        console.log(`Name: ${name}`);
        console.log(`Email: ${email}`);
        console.log(`Event: ${selectedEvent}`);
    }

});