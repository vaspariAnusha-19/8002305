public class Demcompile {
    public void msg() {
        System.out.println("Decompile");
    }
}