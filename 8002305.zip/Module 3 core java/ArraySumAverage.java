import java.util.Scanner;

public class ArraySumAverage {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();

        if (n <= 0) {
            System.out.println("Number of elements must be greater than zero.");
            scanner.close();
            return;
        }

        double[] elements = new double[n];
        System.out.println("Enter " + n + " numbers:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            elements[i] = scanner.nextDouble();
        }

        double sum = 0;
        for (double num : elements) {
            sum += num;
        }
        double average = sum / n;

        System.out.println("\n--- Results ---");
        System.out.println("Sum: " + sum);
        System.out.println("Average: " + average);

        scanner.close();
    }
}