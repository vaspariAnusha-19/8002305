import java.util.ArrayList;
import java.util.List;

public class LambdaSortDemo {
    public static void main(String[] args) {
        List<String> fruits = new ArrayList<>();
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Dragonfruit");
        fruits.add("Cherry");

        System.out.println("Before sorting: " + fruits);

        fruits.sort((s1, s2) -> s1.compareTo(s2));

        System.out.println("After sorting alphabetically: " + fruits);
    }
}