public class PatternMatchingDemo {

    public static void main(String[] args) {
        processObject(42);
        processObject("Hello Java 21");
        processObject(3.14159);
        processObject(true);
        processObject(null);
    }

    public static void processObject(Object obj) {
        String message = switch (obj) {
            case Integer i -> "Input is an Integer: " + i;
            case String s  -> "Input is a String: \"" + s + "\"";
            case Double d  -> "Input is a Double: " + d;
            case null      -> "Input is null";
            default        -> "Input is an unknown type: " + obj.getClass().getSimpleName();
        };

        System.out.println(message);
    }
}