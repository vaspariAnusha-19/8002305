import java.util.Scanner;

public class PalindromeChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string to check: ");
        String userInput = scanner.nextLine();
        String cleanedString = userInput.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
        String reversedString = new StringBuilder(cleanedString).reverse().toString();
        boolean isPalindrome = cleanedString.equals(reversedString);
        if (isPalindrome) {
            System.out.println("'" + userInput + "' is a palindrome!");
        } else {
            System.out.println("'" + userInput + "' is NOT a palindrome.");
        }
        scanner.close();
    }
}