import java.lang.reflect.Method;

public class ReflectionDemo {
    public void hello() {
        System.out.println("Hello Reflection");
    }

    public static void main(String[] args) throws Exception {
        Class<?> c = Class.forName("ReflectionDemo");

        Object obj = c.getDeclaredConstructor().newInstance();

        for (Method m : c.getDeclaredMethods()) {
            System.out.println(m.getName());
        }

        Method m = c.getMethod("hello");
        m.invoke(obj);
    }
}