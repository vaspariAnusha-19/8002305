interface Playable {
    void play();
}

class Football implements Playable {
    @Override
    public void play() {
        System.out.println("Playing football sports game.");
    }
}

public class InterfaceTest {
    public static void main(String[] args) {
        Playable game = new Football();
        game.play();
    }
}