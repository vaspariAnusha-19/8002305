public class TypeCasting {
    public static void main(String[] args) {
        double myDouble = 9.78;
        int doubleToInt = (int) myDouble;
        System.out.println(doubleToInt);

        int myInt = 5;
        double intToDouble = (double) myInt;
        System.out.println(intToDouble);
    }
}