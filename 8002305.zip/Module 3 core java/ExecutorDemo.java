import java.util.concurrent.*;

public class ExecutorDemo {
    public static void main(String[] args) throws Exception {

        ExecutorService ex = Executors.newFixedThreadPool(3);

        Callable<Integer> c1 = () -> 10 + 5;
        Callable<Integer> c2 = () -> 20 * 2;
        Callable<Integer> c3 = () -> 100 / 2;

        System.out.println(ex.submit(c1).get());
        System.out.println(ex.submit(c2).get());
        System.out.println(ex.submit(c3).get());

        ex.shutdown();
    }
}