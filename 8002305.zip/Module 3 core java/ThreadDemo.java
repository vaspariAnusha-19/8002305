class MessagePrinter implements Runnable {
    private String message;

    public MessagePrinter(String message) {
        this.message = message;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(Thread.currentThread().getName() + ": " + message + " (Iteration " + i + ")");
            try {
                Thread.sleep(100); 
            } catch (InterruptedException e) {
                System.out.println("Thread interrupted.");
            }
        }
    }
}

public class ThreadDemo {
    public static void main(String[] args) {
        MessagePrinter printer1 = new MessagePrinter("Hello from Thread A");
        MessagePrinter printer2 = new MessagePrinter("Greetings from Thread B");

        Thread thread1 = new Thread(printer1, "Thread-1");
        Thread thread2 = new Thread(printer2, "Thread-2");

        thread1.start();
        thread2.start();
    }
}