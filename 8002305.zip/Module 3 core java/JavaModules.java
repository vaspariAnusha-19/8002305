package com.greetings;

import com.utils.Util;

public class JavaModules {
    public static void main(String[] args) {
        String message = Util.greet("Student");
        System.out.println(message);
    }
}