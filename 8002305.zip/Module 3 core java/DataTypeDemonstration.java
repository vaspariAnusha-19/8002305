public class DataTypeDemonstration {
    public static void main(String[] args) {
        int myInt = 10;
        float myFloat = 5.99f;
        double myDouble = 19.99;
        char myChar = 'D';
        boolean myBoolean = true;
        System.out.println(myInt);
        System.out.println(myFloat);
        System.out.println(myDouble);
        System.out.println(myChar);
        System.out.println(myBoolean);
    }
}