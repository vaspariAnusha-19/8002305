const form =
    document.querySelector("#registrationForm");

const message =
    document.querySelector("#message");

form.addEventListener("submit", function (event) {

    event.preventDefault();

    const name =
        form.elements["name"].value;

    const email =
        form.elements["email"].value;

    const userData = {
        name,
        email
    };

    message.textContent = "Submitting registration...";
    message.className = "";

    /* Simulate server delay */
    setTimeout(() => {

        fetch(
            "https://jsonplaceholder.typicode.com/posts",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify(userData)
            }
        )
        .then(response => {

            if (!response.ok) {
                throw new Error(
                    "Failed to submit registration"
                );
            }

            return response.json();
        })
        .then(data => {

            message.textContent =
                "Registration successful!";

            message.className = "success";

            console.log("Server Response:", data);

            form.reset();
        })
        .catch(error => {

            message.textContent =
                "Registration failed. Please try again.";

            message.className = "error";

            console.error(error);
        });

    }, 2000); // 2-second delay
});