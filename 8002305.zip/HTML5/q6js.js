/* =========================
   Events Array
   ========================= */
const events = [
    {
        name: "Summer Music Festival",
        category: "Music"
    },
    {
        name: "Baking Workshop",
        category: "Workshop"
    },
    {
        name: "Jazz Night",
        category: "Music"
    }
];

/* =========================
   Add New Events
   Using .push()
   ========================= */
events.push({
    name: "Rock Concert",
    category: "Music"
});

events.push({
    name: "Art Exhibition",
    category: "Art"
});

console.log("All Events:");
console.log(events);


/* =========================
   Filter Music Events
   Using .filter()
   ========================= */
const musicEvents = events.filter(event =>
    event.category === "Music"
);

console.log("\nMusic Events:");
console.log(musicEvents);


/* =========================
   Format Display Cards
   Using .map()
   ========================= */
const eventCards = events.map(event =>
    `${event.category} on ${event.name}`
);

console.log("\nDisplay Cards:");
console.log(eventCards);