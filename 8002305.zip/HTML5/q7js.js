/* =========================
   Event Data
   ========================= */
const events = [
    {
        name: "Music Festival",
        category: "Music",
        seats: 10
    },
    {
        name: "Baking Workshop",
        category: "Workshop",
        seats: 5
    }
];

/* =========================
   Access DOM Element
   ========================= */
const eventsContainer = document.querySelector("#eventsContainer");

/* =========================
   Render Events
   ========================= */
function renderEvents() {

    // Clear existing content
    eventsContainer.innerHTML = "";

    events.forEach((event, index) => {

        // Create card
        const card = document.createElement("div");
        card.classList.add("event-card");

        card.innerHTML = `
            <h3>${event.name}</h3>
            <p>Category: ${event.category}</p>
            <p>Available Seats: ${event.seats}</p>

            <button onclick="register(${index})">
                Register
            </button>

            <button onclick="cancel(${index})">
                Cancel
            </button>
        `;

        // Append card to container
        eventsContainer.appendChild(card);
    });
}

/* =========================
   Register User
   ========================= */
function register(index) {

    if (events[index].seats > 0) {
        events[index].seats--;
        renderEvents(); // Update UI
    } else {
        alert("No seats available!");
    }
}

/* =========================
   Cancel Registration
   ========================= */
function cancel(index) {

    events[index].seats++;
    renderEvents(); // Update UI
}

/* =========================
   Initial Display
   ========================= */
renderEvents();