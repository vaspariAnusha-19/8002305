// Constants (cannot be changed)
const eventName = "Community Clean-Up Drive";
const eventDate = "15 June 2026";

// Variable (can be updated)
let availableSeats = 50;

// Display event information using template literals
console.log(`Event: ${eventName}`);
console.log(`Date: ${eventDate}`);
console.log(`Available Seats: ${availableSeats}`);

// A participant registers
availableSeats--;

// Display updated seat count
console.log(`After registration, available seats: ${availableSeats}`);

// Another participant registers
availableSeats--;

// Display updated seat count
console.log(`After another registration, available seats: ${availableSeats}`);

// Registration cancellation (seat becomes available)
availableSeats++;

// Display final seat count
console.log(`After cancellation, available seats: ${availableSeats}`);

// Complete event information
console.log(
    `Event "${eventName}" is scheduled on ${eventDate}. Remaining seats: ${availableSeats}`
);