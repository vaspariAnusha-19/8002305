/* =========================
   Event Data
   ========================= */
const events = [
    { name: "Music Festival", category: "Music", seats: 10 },
    { name: "Baking Workshop", category: "Workshop", seats: 5 },
    { name: "Football Tournament", category: "Sports", seats: 15 }
];

const eventsContainer =
    document.querySelector("#eventsContainer");

const categoryFilter =
    document.querySelector("#categoryFilter");

const searchInput =
    document.querySelector("#searchInput");


/* =========================
   Display Events
   ========================= */
function renderEvents(eventList) {

    eventsContainer.innerHTML = "";

    eventList.forEach((event, index) => {

        const card = document.createElement("div");
        card.classList.add("event-card");

        card.innerHTML = `
            <h3>${event.name}</h3>
            <p>Category: ${event.category}</p>
            <p>Seats: ${event.seats}</p>

            <button onclick="register(${index})">
                Register
            </button>
        `;

        eventsContainer.appendChild(card);
    });
}


/* =========================
   onclick Event
   Register Button
   ========================= */
function register(index) {

    if (events[index].seats > 0) {
        events[index].seats--;

        alert(
            `Registered for ${events[index].name}`
        );

        renderEvents(events);
    } else {
        alert("No seats available!");
    }
}


/* =========================
   onchange Event
   Category Filter
   ========================= */
categoryFilter.onchange = function () {

    const selectedCategory = this.value;

    if (selectedCategory === "All") {
        renderEvents(events);
        return;
    }

    const filteredEvents = events.filter(
        event => event.category === selectedCategory
    );

    renderEvents(filteredEvents);
};


/* =========================
   keydown Event
   Search by Name
   ========================= */
searchInput.addEventListener("keydown", function () {

    const searchText =
        searchInput.value.toLowerCase();

    const filteredEvents = events.filter(
        event =>
            event.name.toLowerCase().includes(searchText)
    );

    setTimeout(() => {
        renderEvents(filteredEvents);
    }, 0);
});


/* =========================
   Initial Display
   ========================= */
renderEvents(events);