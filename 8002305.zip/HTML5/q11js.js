const form =
    document.querySelector("#registrationForm");

const successMessage =
    document.querySelector("#successMessage");

form.addEventListener("submit", function (event) {

    /* Prevent page reload */
    event.preventDefault();

    /* Clear previous messages */
    document.querySelector("#nameError").textContent = "";
    document.querySelector("#emailError").textContent = "";
    document.querySelector("#eventError").textContent = "";
    successMessage.textContent = "";

    /* Access inputs using form.elements */
    const name =
        form.elements["name"].value.trim();

    const email =
        form.elements["email"].value.trim();

    const selectedEvent =
        form.elements["event"].value;

    let isValid = true;

    /* Validate Name */
    if (name === "") {
        document.querySelector("#nameError")
            .textContent = "Name is required.";
        isValid = false;
    }

    /* Validate Email */
    if (email === "") {
        document.querySelector("#emailError")
            .textContent = "Email is required.";
        isValid = false;
    } else if (!email.includes("@")) {
        document.querySelector("#emailError")
            .textContent = "Enter a valid email.";
        isValid = false;
    }

    /* Validate Event Selection */
    if (selectedEvent === "") {
        document.querySelector("#eventError")
            .textContent = "Please select an event.";
        isValid = false;
    }

    /* If valid */
    if (isValid) {

        successMessage.textContent =
            `Successfully registered ${name} for ${selectedEvent}!`;

        console.log({
            name,
            email,
            selectedEvent
        });

        form.reset();
    }
});