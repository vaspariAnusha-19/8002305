// Event storage
const events = [];

/* =========================
   Add Event Function
   ========================= */
function addEvent(name, category, seats) {
    events.push({
        name,
        category,
        seats
    });

    console.log(`Event "${name}" added.`);
}


/* =========================
   Register User Function
   ========================= */
function registerUser(eventName) {
    const event = events.find(e => e.name === eventName);

    if (!event) {
        console.log("Event not found.");
        return;
    }

    if (event.seats <= 0) {
        console.log(`No seats available for ${event.name}.`);
        return;
    }

    event.seats--;
    console.log(`Registered for ${event.name}. Remaining seats: ${event.seats}`);
}


/* =========================
   Higher-Order Function
   Filter Events Using Callback
   ========================= */
function filterEventsByCategory(eventList, callback) {
    return eventList.filter(callback);
}


/* =========================
   Closure Example
   Track Registrations
   ========================= */
function registrationTracker(category) {
    let totalRegistrations = 0; // Private variable

    return function () {
        totalRegistrations++;
        console.log(
            `${category} registrations: ${totalRegistrations}`
        );
    };
}


/* =========================
   Add Sample Events
   ========================= */
addEvent("Community Meeting", "Community", 20);
addEvent("Football Tournament", "Sports", 30);
addEvent("Health Camp", "Health", 15);
addEvent("Basketball Match", "Sports", 25);


/* =========================
   Register Users
   ========================= */
registerUser("Football Tournament");
registerUser("Football Tournament");


/* =========================
   Closure Usage
   ========================= */
const sportsRegistrationCounter =
    registrationTracker("Sports");

sportsRegistrationCounter();
sportsRegistrationCounter();
sportsRegistrationCounter();


/* =========================
   Dynamic Search with Callback
   ========================= */

// Find all Sports events
const sportsEvents = filterEventsByCategory(
    events,
    event => event.category === "Sports"
);

console.log("Sports Events:");
console.log(sportsEvents);


// Find events with more than 20 seats
const availableEvents = filterEventsByCategory(
    events,
    event => event.seats > 20
);

console.log("Events with more than 20 seats:");
console.log(availableEvents);