form.addEventListener("submit", function (event) {

    console.log("Form submitted");

    event.preventDefault();

    const name = form.elements["name"].value;
    const email = form.elements["email"].value;

    console.log("Name:", name);
    console.log("Email:", email);

    const userData = {
        name,
        email
    };

    console.log("Payload:", userData);

    fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(userData)
    })
    .then(response => {
        console.log("Response received:", response);
        return response.json();
    })
    .then(data => {
        console.log("Server data:", data);
    })
    .catch(error => {
        console.error("Fetch Error:", error);
    });
});