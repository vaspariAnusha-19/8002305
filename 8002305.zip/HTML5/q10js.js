/* =========================
   Event List
   ========================= */
const events = [
    {
        id: 1,
        name: "Music Festival",
        category: "Music",
        seats: 50
    },
    {
        id: 2,
        name: "Baking Workshop",
        category: "Workshop",
        seats: 20
    },
    {
        id: 3,
        name: "Rock Concert",
        category: "Music",
        seats: 100
    }
];

/* =========================
   Function with Default Parameter
   ========================= */
function addEvent(
    name = "Untitled Event",
    category = "General",
    seats = 0
) {
    const newEvent = {
        name,
        category,
        seats
    };

    console.log("New Event Added:", newEvent);
}

/* Call Function */
addEvent("Photography Workshop", "Workshop", 30);
addEvent(); // Uses default values


/* =========================
   Destructuring
   Extract Event Details
   ========================= */
const firstEvent = events[0];

const {
    name,
    category,
    seats
} = firstEvent;

console.log("Event Details:");
console.log(name);
console.log(category);
console.log(seats);


/* =========================
   Spread Operator
   Clone Event List
   ========================= */
const clonedEvents = [...events];

/* Filter Music Events */
const musicEvents = clonedEvents.filter(
    event => event.category === "Music"
);

console.log("Music Events:");
console.log(musicEvents);


/* =========================
   let and const
   ========================= */

// const → value won't be reassigned
const portalName = "Community Portal";

// let → value can change
let registeredUsers = 10;

registeredUsers++;

console.log(portalName);
console.log(`Registered Users: ${registeredUsers}`);