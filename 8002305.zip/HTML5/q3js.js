// Event list
const events = [
    {
        name: "Community Meeting",
        date: "2026-06-15",
        seats: 20
    },
    {
        name: "Tree Plantation Drive",
        date: "2025-01-10", // Past event
        seats: 15
    },
    {
        name: "Health Awareness Camp",
        date: "2026-07-20",
        seats: 0 // Full event
    },
    {
        name: "Sports Tournament",
        date: "2026-08-05",
        seats: 30
    }
];

const today = new Date();

/* Display only valid events */
console.log("Upcoming Events:\n");

events.forEach(event => {
    const eventDate = new Date(event.date);

    if (eventDate > today && event.seats > 0) {
        console.log(
            `${event.name} | Date: ${event.date} | Seats Available: ${event.seats}`
        );
    } else {
        console.log(`${event.name} is hidden (past or full).`);
    }
});


/* Registration Function with Error Handling */
function registerForEvent(event) {
    try {
        if (!event) {
            throw new Error("Event not found.");
        }

        if (event.seats <= 0) {
            throw new Error(`Registration failed: ${event.name} is full.`);
        }

        event.seats--; // Reserve a seat

        console.log(
            `Successfully registered for ${event.name}. Remaining seats: ${event.seats}`
        );

    } catch (error) {
        console.error(error.message);
    }
}


/* Test Registrations */

// Successful registration
registerForEvent(events[0]);

// Attempt to register for a full event
registerForEvent(events[2]);

// Attempt to register for a non-existent event
registerForEvent(null);