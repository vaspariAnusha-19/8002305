$(document).ready(function () {

    /* Handle Register Button Click */
    $("#registerBtn").click(function () {

        $(".event-card").fadeIn(1000);

        alert("Registration successful!");
    });

    /* Handle Hide Button Click */
    $("#hideBtn").click(function () {

        $(".event-card").fadeOut(1000);
    });

});