/* =========================
   Event Constructor
   ========================= */
function Event(name, date, category, seats) {
    this.name = name;
    this.date = date;
    this.category = category;
    this.seats = seats;
}

/* =========================
   Prototype Method
   ========================= */
Event.prototype.checkAvailability = function () {
    if (this.seats > 0) {
        return `${this.name} has ${this.seats} seats available.`;
    } else {
        return `${this.name} is fully booked.`;
    }
};

/* =========================
   Create Event Objects
   ========================= */
const event1 = new Event(
    "Community Meeting",
    "2026-06-15",
    "Community",
    25
);

const event2 = new Event(
    "Health Camp",
    "2026-07-10",
    "Health",
    0
);

/* =========================
   Use Prototype Method
   ========================= */
console.log(event1.checkAvailability());
console.log(event2.checkAvailability());

/* =========================
   Object.entries()
   ========================= */
console.log("\nEvent Details:");

Object.entries(event1).forEach(([key, value]) => {
    console.log(`${key}: ${value}`);
});