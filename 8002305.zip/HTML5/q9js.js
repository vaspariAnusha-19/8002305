const eventsContainer =
    document.querySelector("#eventsContainer");

const loader =
    document.querySelector("#loader");

/* Show Loading Spinner */
loader.style.display = "block";

/* Fetch Events */
fetch("https://jsonplaceholder.typicode.com/users")
    .then(response => {

        if (!response.ok) {
            throw new Error("Failed to fetch data");
        }

        return response.json();
    })
    .then(data => {

        loader.style.display = "none";

        data.forEach(event => {

            const card =
                document.createElement("div");

            card.classList.add("event-card");

            card.innerHTML = `
                <h3>${event.name}</h3>
                <p>${event.email}</p>
            `;

            eventsContainer.appendChild(card);
        });
    })
    .catch(error => {

        loader.style.display = "none";

        console.error(error);

        eventsContainer.innerHTML =
            "<p>Error loading events.</p>";
    });