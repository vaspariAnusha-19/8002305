import java.util.Scanner;

public class LeapYearChecker {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a year
        System.out.print("Enter a year: ");
        int year = scanner.nextInt();

        // Check leap year conditions
        if (year % 4 == 0) {

            if (year % 100 == 0) {

                if (year % 400 == 0) {
                    System.out.println(year + " is a Leap Year.");
                } else {
                    System.out.println(year + " is NOT a Leap Year.");
                }

            } else {
                System.out.println(year + " is a Leap Year.");
            }

        } else {
            System.out.println(year + " is NOT a Leap Year.");
        }

        scanner.close();
    }
}