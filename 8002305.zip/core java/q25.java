import java.util.HashMap;
import java.util.Scanner;

public class HashMapExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a HashMap with Integer keys and String values
        HashMap<Integer, String> students = new HashMap<>();

        // Ask the user how many entries to add
        System.out.print("How many students would you like to add? ");
        int count = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Add entries to the HashMap
        for (int i = 1; i <= count; i++) {
            System.out.print("Enter Student ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter Student Name: ");
            String name = scanner.nextLine();

            students.put(id, name);
        }

        // Retrieve a name based on an entered ID
        System.out.print("\nEnter a Student ID to search: ");
        int searchId = scanner.nextInt();

        if (students.containsKey(searchId)) {
            System.out.println("Student Name: " + students.get(searchId));
        } else {
            System.out.println("No student found with ID " + searchId);
        }

        scanner.close();
    }
}