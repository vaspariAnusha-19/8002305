public class PatternMatchingSwitchExample {

    // Method that accepts Object as input
    public static void printTypeInfo(Object obj) {
        switch (obj) {
            case Integer i ->
                System.out.println("Integer value: " + i);

            case String s ->
                System.out.println("String value: " + s);

            case Double d ->
                System.out.println("Double value: " + d);

            case Boolean b ->
                System.out.println("Boolean value: " + b);

            case null ->
                System.out.println("Object is null");

            default ->
                System.out.println("Unknown type: " + obj.getClass().getSimpleName());
        }
    }

    public static void main(String[] args) {
        printTypeInfo(42);
        printTypeInfo("Hello, Java 21!");
        printTypeInfo(3.14);
        printTypeInfo(true);
        printTypeInfo(new Object());
        printTypeInfo(null);
    }
}