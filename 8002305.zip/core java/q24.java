import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList to store student names
        ArrayList<String> studentNames = new ArrayList<>();

        // Ask the user how many names to add
        System.out.print("How many student names would you like to enter? ");
        int count = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Add names to the ArrayList
        for (int i = 1; i <= count; i++) {
            System.out.print("Enter student name " + i + ": ");
            String name = scanner.nextLine();
            studentNames.add(name);
        }

        // Display all names entered
        System.out.println("\nStudent Names:");
        for (String name : studentNames) {
            System.out.println(name);
        }

        scanner.close();
    }
}