// Define the interface
interface Playable {
    void play();
}

// Implement the interface in Guitar class
class Guitar implements Playable {
    @Override
    public void play() {
        System.out.println("Playing the Guitar");
    }
}

// Implement the interface in Piano class
class Piano implements Playable {
    @Override
    public void play() {
        System.out.println("Playing the Piano");
    }
}

// Main class
public class Main {
    public static void main(String[] args) {
        // Instantiate the classes
        Playable guitar = new Guitar();
        Playable piano = new Piano();

        // Call the play() method
        guitar.play();
        piano.play();
    }
}