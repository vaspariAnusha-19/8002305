# Palindrome Checker

# Prompt the user for a string
text = input("Enter a string: ")

# Remove non-alphanumeric characters and convert to lowercase
cleaned_text = "".join(char.lower() for char in text if char.isalnum())

# Check if the string is a palindrome
if cleaned_text == cleaned_text[::-1]:
    print("The string is a palindrome.")
else:
    print("The string is not a palindrome.")