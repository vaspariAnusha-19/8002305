public class DataTypeDemo {

    public static void main(String[] args) {

        // Declare variables of different primitive data types
        int age = 20;
        float height = 5.8f;
        double salary = 45000.75;
        char grade = 'A';
        boolean isStudent = true;

        // Display the values
        System.out.println("Integer Value (age): " + age);
        System.out.println("Float Value (height): " + height);
        System.out.println("Double Value (salary): " + salary);
        System.out.println("Character Value (grade): " + grade);
        System.out.println("Boolean Value (isStudent): " + isStudent);
    }
}