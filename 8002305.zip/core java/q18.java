# Base class
class Animal:
    def makeSound(self):
        print("Some generic animal sound")

# Subclass
class Dog(Animal):
    # Override the makeSound() method
    def makeSound(self):
        print("Bark")

# Instantiate objects
animal = Animal()
dog = Dog()

# Call methods
animal.makeSound()
dog.makeSound()