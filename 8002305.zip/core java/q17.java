# Define the Car class
class Car:
    # Constructor to initialize attributes
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year

    # Method to display car details
    def displayDetails(self):
        print("Car Information:")
        print("Make :", self.make)
        print("Model:", self.model)
        print("Year :", self.year)
        print()

# Create objects of the Car class
car1 = Car("Toyota", "Corolla", 2022)
car2 = Car("Honda", "Civic", 2021)

# Call the method for each object
car1.displayDetails()
car2.displayDetails()