import java.util.concurrent.*;
import java.util.*;

public class CallableExample {
    public static void main(String[] args) {
        
        // Create a fixed thread pool with 3 threads
        ExecutorService executor = Executors.newFixedThreadPool(3);

        // List to store Future objects
        List<Future<String>> futures = new ArrayList<>();

        // Submit Callable tasks
        for (int i = 1; i <= 5; i++) {
            int taskId = i;

            Callable<String> task = () -> {
                Thread.sleep(1000); // Simulate work
                return "Task " + taskId + " completed by " +
                       Thread.currentThread().getName();
            };

            futures.add(executor.submit(task));
        }

        // Collect results using Future.get()
        for (Future<String> future : futures) {
            try {
                String result = future.get();
                System.out.println(result);
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }

        // Shutdown executor
        executor.shutdown();
    }
}