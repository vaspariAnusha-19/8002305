import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner sc = new Scanner(System.in);

        // Generate a random number between 1 and 100
        int secretNumber = random.nextInt(100) + 1;

        int guess;

        System.out.println("=== Number Guessing Game ===");
        System.out.println("I have chosen a number between 1 and 100.");

        // Continue until the user guesses correctly
        do {
            System.out.print("Enter your guess: ");
            guess = sc.nextInt();

            if (guess > secretNumber) {
                System.out.println("Too high! Try again.");
            } else if (guess < secretNumber) {
                System.out.println("Too low! Try again.");
            } else {
                System.out.println("Congratulations! You guessed the number correctly.");
            }

        } while (guess != secretNumber);

        sc.close();
    }
}