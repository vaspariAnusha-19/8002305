public class TypeCastingExample {

    public static void main(String[] args) {

        // Declare a double variable
        double decimalNumber = 45.78;

        // Explicitly cast double to int
        int integerValue = (int) decimalNumber;

        System.out.println("Original double value: " + decimalNumber);
        System.out.println("After casting to int: " + integerValue);

        // Declare an int variable
        int number = 25;

        // Implicitly cast int to double
        double doubleValue = number;

        System.out.println("Original int value: " + number);
        System.out.println("After casting to double: " + doubleValue);
    }
}