import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

// Class to be loaded dynamically
class Calculator {

    public void greet(String name) {
        System.out.println("Hello, " + name + "!");
    }

    public int add(int a, int b) {
        return a + b;
    }
}

public class ReflectionExample {

    public static void main(String[] args) {

        try {
            // Load class dynamically
            Class<?> clazz = Class.forName("Calculator");

            // Create object dynamically
            Object obj = clazz.getDeclaredConstructor().newInstance();

            // Get all declared methods
            Method[] methods = clazz.getDeclaredMethods();

            System.out.println("Methods in Calculator class:\n");

            for (Method method : methods) {

                System.out.println("Method Name: " + method.getName());

                Parameter[] parameters = method.getParameters();

                System.out.println("Parameters:");

                if (parameters.length == 0) {
                    System.out.println("  No parameters");
                } else {
                    for (Parameter p : parameters) {
                        System.out.println("  " +
                                p.getType().getSimpleName() +
                                " " + p.getName());
                    }
                }

                System.out.println();
            }

            // Invoke greet(String)
            Method greetMethod =
                    clazz.getMethod("greet", String.class);

            System.out.println("Invoking greet()...");
            greetMethod.invoke(obj, "Alice");

            // Invoke add(int, int)
            Method addMethod =
                    clazz.getMethod("add",
                            int.class,
                            int.class);

            Object result =
                    addMethod.invoke(obj, 10, 20);

            System.out.println("Result of add(): " + result);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}