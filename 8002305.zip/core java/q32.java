import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

// Student Class
class Student {
    private int id;
    private String name;
    private int age;

    public Student(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}

// StudentDAO Class
class StudentDAO {

    private static final String URL =
            "jdbc:mysql://localhost:3306/school";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    // Insert Student
    public void insertStudent(Student student) {
        String sql = "INSERT INTO students(id, name, age) VALUES (?, ?, ?)";

        try (Connection conn =
                     DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt =
                     conn.prepareStatement(sql)) {

            pstmt.setInt(1, student.getId());
            pstmt.setString(2, student.getName());
            pstmt.setInt(3, student.getAge());

            int rows = pstmt.executeUpdate();
            System.out.println(rows + " record inserted.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Update Student
    public void updateStudent(int id, String newName, int newAge) {
        String sql = "UPDATE students SET name = ?, age = ? WHERE id = ?";

        try (Connection conn =
                     DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt =
                     conn.prepareStatement(sql)) {

            pstmt.setString(1, newName);
            pstmt.setInt(2, newAge);
            pstmt.setInt(3, id);

            int rows = pstmt.executeUpdate();
            System.out.println(rows + " record updated.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

// Main Class
public class JDBCInsertUpdateExample {

    public static void main(String[] args) {

        StudentDAO dao = new StudentDAO();

        // Create Student Object
        Student student = new Student(101, "Alice", 20);

        // Insert Record
        dao.insertStudent(student);

        // Update Record
        dao.updateStudent(101, "Alice Johnson", 21);
    }
}