import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class TransactionExample {

    private static final String URL =
            "jdbc:mysql://localhost:3306/bankdb";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    public static void transfer(int fromAccount,
                                int toAccount,
                                double amount) {

        Connection conn = null;

        try {
            // Establish connection
            conn = DriverManager.getConnection(URL, USER, PASSWORD);

            // Start transaction
            conn.setAutoCommit(false);

            // Debit query
            String debitQuery =
                    "UPDATE accounts SET balance = balance - ? WHERE id = ?";

            PreparedStatement debitStmt =
                    conn.prepareStatement(debitQuery);

            debitStmt.setDouble(1, amount);
            debitStmt.setInt(2, fromAccount);

            int debitRows = debitStmt.executeUpdate();

            // Credit query
            String creditQuery =
                    "UPDATE accounts SET balance = balance + ? WHERE id = ?";

            PreparedStatement creditStmt =
                    conn.prepareStatement(creditQuery);

            creditStmt.setDouble(1, amount);
            creditStmt.setInt(2, toAccount);

            int creditRows = creditStmt.executeUpdate();

            // Check if both operations succeeded
            if (debitRows > 0 && creditRows > 0) {
                conn.commit();
                System.out.println("Transaction Successful!");
            } else {
                conn.rollback();
                System.out.println("Transaction Failed. Rolled Back.");
            }

            debitStmt.close();
            creditStmt.close();

        } catch (Exception e) {
            try {
                if (conn != null) {
                    conn.rollback();
                    System.out.println("Transaction Failed. Rolled Back.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();

        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {

        // Transfer ₹1000 from Account 1 to Account 2
        transfer(1, 2, 1000);
    }
}