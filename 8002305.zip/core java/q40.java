import java.util.ArrayList;
import java.util.List;

public class VirtualThreadDemo {

    private static final int VIRTUAL_THREAD_COUNT = 100_000;
    private static final int PLATFORM_THREAD_COUNT = 10_000; // safer limit

    public static void main(String[] args) throws InterruptedException {

        // Virtual Threads Benchmark
        long virtualStart = System.currentTimeMillis();

        List<Thread> virtualThreads = new ArrayList<>();

        for (int i = 0; i < VIRTUAL_THREAD_COUNT; i++) {
            int id = i;

            Thread vt = Thread.startVirtualThread(() -> {
                System.out.println("Virtual Thread #" + id);
            });

            virtualThreads.add(vt);
        }

        for (Thread t : virtualThreads) {
            t.join();
        }

        long virtualEnd = System.currentTimeMillis();

        System.out.println("\nVirtual Threads Time: "
                + (virtualEnd - virtualStart) + " ms");

        // Platform Threads Benchmark
        long platformStart = System.currentTimeMillis();

        List<Thread> platformThreads = new ArrayList<>();

        for (int i = 0; i < PLATFORM_THREAD_COUNT; i++) {
            int id = i;

            Thread pt = new Thread(() -> {
                System.out.println("Platform Thread #" + id);
            });

            pt.start();
            platformThreads.add(pt);
        }

        for (Thread t : platformThreads) {
            t.join();
        }

        long platformEnd = System.currentTimeMillis();

        System.out.println("\nPlatform Threads Time: "
                + (platformEnd - platformStart) + " ms");
    }
}