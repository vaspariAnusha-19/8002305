import java.util.List;
import java.util.stream.Collectors;

// Define a record named Person
record Person(String name, int age) {}

public class RecordExample {
    public static void main(String[] args) {

        // Create instances of Person
        Person p1 = new Person("Alice", 25);
        Person p2 = new Person("Bob", 17);
        Person p3 = new Person("Charlie", 30);

        // Print the record instances
        System.out.println("Individual Persons:");
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);

        // Store records in a List
        List<Person> people = List.of(p1, p2, p3);

        // Filter people whose age is 18 or older
        List<Person> adults = people.stream()
                                    .filter(person -> person.age() >= 18)
                                    .collect(Collectors.toList());

        // Display filtered results
        System.out.println("\nAdults (Age >= 18):");
        adults.forEach(System.out::println);
    }
}