public class OperatorPrecedenceDemo {
    public static void main(String[] args) {

        int result1 = 10 + 5 * 2;
        int result2 = (10 + 5) * 2;
        int result3 = 20 - 4 / 2 + 3;
        int result4 = 8 + 2 * 3 - 4 / 2;

        System.out.println("10 + 5 * 2 = " + result1);
        System.out.println("(10 + 5) * 2 = " + result2);
        System.out.println("20 - 4 / 2 + 3 = " + result3);
        System.out.println("8 + 2 * 3 - 4 / 2 = " + result4);
    }
}